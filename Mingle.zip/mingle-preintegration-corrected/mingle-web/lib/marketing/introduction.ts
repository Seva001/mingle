/**
 * Copy for the landing introduction (F2.4). Kept as plain data so tests can enforce the
 * messaging rules (brief §6, §15): no guarantees, no statistics or testimonials, no claim
 * that compatibility is scientific or predictive, and no sensitive traits in scoring.
 */
export type PillarKey = "values" | "lifestyle" | "discovery" | "connection";

export const introduction = {
  id: "introduction",
  eyebrow: "What Mingle is",
  title: "Not just another profile. A better way to connect.",
  lead: "Mingle is a compatibility-first platform for adults aged 18 and over. It’s built around the things that shape how well two people connect: shared interests, personal values, lifestyle and what each person is looking for.",
  blocks: [
    {
      title: "The problem we’re addressing",
      body: "A photo and a few seconds say very little about who someone is or what they want. When discovery rests on quick judgements, it’s easy to spend time on introductions that never had much in common to begin with.",
    },
    {
      title: "Why compatibility matters",
      body: "Attraction can start a conversation. Shared values, compatible lifestyles and similar intentions help it continue. Knowing a little of this early means less guesswork about whether you’re looking for the same thing.",
    },
  ],
  comparison: {
    title: "Swipe-first discovery and Mingle",
    swipeLabel: "Swipe-first",
    mingleLabel: "Mingle",
    rows: [
      {
        aspect: "First impression",
        swipe: "A photo and a short bio.",
        mingle: "Photos alongside values, lifestyle and what you’re looking for.",
      },
      {
        aspect: "Finding people",
        swipe: "Scrolling through an endless stream.",
        mingle: "Recommendations shaped by the preferences you choose to share.",
      },
      {
        aspect: "Starting a conversation",
        swipe: "A match, then a blank chat.",
        mingle: "Shared ground to start from.",
      },
      {
        aspect: "Pace",
        swipe: "Fast, high-volume choices.",
        mingle: "More deliberate, by design.",
      },
    ],
    note: "A general contrast, not a comparison with any particular app.",
  },
  pillars: [
    {
      key: "values",
      title: "Shared interests and values",
      body: "Start from what you genuinely have in common.",
    },
    {
      key: "lifestyle",
      title: "Lifestyle compatibility",
      body: "Everyday rhythms and preferences count too.",
    },
    {
      key: "discovery",
      title: "Intentional discovery",
      body: "Spend your attention on people who are relevant to you.",
    },
    {
      key: "connection",
      title: "Meaningful connection",
      body: "Conversations that begin with something real to talk about.",
    },
  ],
  note: "Compatibility is a starting point, not a promise. Mingle uses the preferences you choose to share, doesn’t use sensitive traits such as religion, politics, ethnicity or health to work out compatibility, and can’t guarantee a match or a relationship.",
} as const;
