/**
 * Copy for the Help (F2.12) and FAQ (F2.13) pages.
 *
 * Plain data, so tests can enforce the same messaging rules as the About and How It Works pages
 * (brief §6, §15): no guarantees, statistics, testimonials or safety promises, no sensitive
 * traits used for compatibility, and nothing described as live before it exists.
 *
 * NO SUPPORT CHANNELS ARE INVENTED. There is no support address, contact form, chat, phone
 * number, help-desk or response-time promise anywhere in this repository, so none is written
 * here. `supportStatus` says so plainly. When a real channel exists, add it there and the
 * tests will keep the rest honest.
 *
 * Every statement about what works today is tied to the source by tests/support-pages.test.ts,
 * the same way the How It Works labels are.
 */

export type SupportLink = { label: string; href: string };

/* ------------------------------------------------------------------------------- help */

export const supportStatus = {
  id: "support",
  title: "Contact and support",
  lead: "Mingle doesn’t have a published way to contact support yet.",
  body: "Accounts aren’t open and there are no members, so there is no support service to reach. When a support process exists, this page will say how to use it. Until then, this page and the FAQ are the only help available.",
  emergency:
    "If you or someone else is in immediate danger, contact your local emergency services. Mingle can’t respond to emergencies.",
} as const;

export type HelpTopic = {
  id: string;
  title: string;
  summary: string;
  items: readonly { title: string; body: string }[];
  links?: readonly SupportLink[];
};

export const help = {
  eyebrow: "Help",
  title: "Help, in plain words.",
  lead: "Guidance on how Mingle is meant to work, grouped by topic. Mingle is still being built, so each topic says what exists today and what doesn’t.",
  status: {
    title: "Read this first",
    body: "Mingle isn’t open yet. Accounts aren’t available and there are no members. Where this page describes the member experience, it describes what Mingle is designed to do, and says when something works only as a preview.",
  },
  navTitle: "On this page",
  faqLink: {
    label: "Read the frequently asked questions",
    href: "/faq",
  },

  topics: [
    {
      id: "getting-started",
      title: "Getting started",
      summary: "What Mingle is and what you can do with it at the moment.",
      items: [
        {
          title: "What Mingle is",
          body: "Mingle is a compatibility-first platform for adults aged 18 and over. It’s designed to help people meet others who share their values and are looking for the same kind of relationship.",
        },
        {
          title: "What you can do today",
          body: "You can read about Mingle and look through the preview build. The preview uses made-up sample profiles and keeps your actions in your own browser. Nothing is sent to an account or shown to anyone.",
        },
        {
          title: "What you can’t do yet",
          body: "You can’t create a working account, meet real members or send messages. Those parts are still being built.",
        },
      ],
      links: [
        { label: "See the whole journey", href: "/how-it-works" },
        { label: "About Mingle", href: "/about" },
      ],
    },
    {
      id: "age-and-eligibility",
      title: "Age and eligibility",
      summary: "Who Mingle is for and how that is meant to be checked.",
      items: [
        {
          title: "Who can use Mingle",
          body: "Mingle is for adults aged 18 and over. Nobody under 18 may use it.",
        },
        {
          title: "Date of birth at sign-up",
          body: "The sign-up form asks for your date of birth and doesn’t continue if you are under 18. A date you type in isn’t proof of age, so it is only the first step.",
        },
        {
          title: "Further age checks",
          body: "Member features are designed to stay closed until age checks are passed. The age-check service hasn’t been chosen yet, so this part isn’t working.",
        },
      ],
      links: [{ label: "Eligibility, step by step", href: "/how-it-works#eligibility" }],
    },
    {
      id: "profile-and-compatibility",
      title: "Your profile and compatibility",
      summary: "What you share, and how suggestions are meant to be made.",
      items: [
        {
          title: "Building your profile",
          body: "In the preview you can add a name, a short introduction, photos, interests and answers to short questions. You choose how much to say, and you can skip any question.",
        },
        {
          title: "How suggestions are made",
          body: "Suggestions lean toward people whose relationship intentions, values, lifestyle, interests and communication preferences overlap with yours. Each is meant to give its reasons in words.",
        },
        {
          title: "What compatibility can’t do",
          body: "Compatibility is guidance about where to start. It can’t predict whether two people will get along, and Mingle can’t guarantee a match or a relationship. You won’t see a compatibility percentage or score.",
        },
        {
          title: "What isn’t used",
          body: "Mingle doesn’t use religion, ethnicity, politics or health to work out compatibility.",
        },
      ],
      links: [{ label: "Why Mingle works this way", href: "/about#philosophy" }],
    },
    {
      id: "privacy-and-your-data",
      title: "Privacy and your data",
      summary: "What is stored today, and where the policy stands.",
      items: [
        {
          title: "Privacy policy",
          body: "The privacy policy hasn’t been published. It needs legal review first, and it should be in place before accounts open.",
        },
        {
          title: "In the preview",
          body: "Your preview profile and your actions stay in your own browser. Clearing your browser’s site data removes them.",
        },
        {
          title: "Photos",
          body: "In the preview, photos are re-encoded in your browser, which removes location and camera details stored inside the file. They aren’t uploaded anywhere.",
        },
        {
          title: "Controlling who sees you",
          body: "The preview has a switch to hide your profile. Controls for real members are planned.",
        },
      ],
      links: [
        { label: "Privacy policy (in progress)", href: "/privacy" },
        { label: "Cookies (in progress)", href: "/cookies" },
      ],
    },
    {
      id: "accounts-and-sign-in",
      title: "Accounts and sign-in",
      summary: "Signing up, signing in and email confirmation.",
      items: [
        {
          title: "Creating an account",
          body: "Sign-up isn’t open. The form is there so you can see what it will ask for, but it can’t create an account at the moment, and it says so if you try.",
        },
        {
          title: "Signing in",
          body: "There are no accounts to sign in to yet. Passwords will need at least ten characters.",
        },
        {
          title: "Email confirmation",
          body: "Confirming your email is planned as part of sign-up. No email service is connected yet, so nothing is sent.",
        },
      ],
      links: [
        { label: "Get started", href: "/sign-up" },
        { label: "Sign in", href: "/sign-in" },
      ],
    },
    {
      id: "safety-and-respect",
      title: "Safety and respect",
      summary: "What is being designed, and what doesn’t exist yet.",
      items: [
        {
          title: "Blocking and reporting",
          body: "Blocking and reporting are being designed. They don’t work yet, and there is nobody to receive a report.",
        },
        {
          title: "Moderation and support",
          body: "Moderation and support processes are being planned. Mingle will describe a safety feature as available only once it works.",
        },
        {
          title: "Community standards",
          body: "Community guidelines are being written. They haven’t been published or legally reviewed.",
        },
      ],
      links: [
        { label: "Safety centre (in progress)", href: "/safety" },
        { label: "Community guidelines (in progress)", href: "/community-guidelines" },
      ],
    },
    {
      id: "availability",
      title: "Availability",
      summary: "When and where Mingle will be open.",
      items: [
        {
          title: "When Mingle opens",
          body: "There is no launch date. Mingle will open only when its safety, privacy and legal groundwork is in place.",
        },
        {
          title: "Where Mingle opens",
          body: "The first countries and languages haven’t been decided. Mingle is built in English for now.",
        },
        {
          title: "Cost",
          body: "Pricing hasn’t been decided, and nothing can be bought.",
        },
      ],
      links: [{ label: "Where Mingle is heading", href: "/about#direction" }],
    },
  ],
} as const satisfies {
  eyebrow: string;
  title: string;
  lead: string;
  status: { title: string; body: string };
  navTitle: string;
  faqLink: SupportLink;
  topics: readonly HelpTopic[];
};

/* -------------------------------------------------------------------------------- faq */

export type FaqItem = { id: string; question: string; answer: readonly string[] };
export type FaqCategory = {
  id: string;
  title: string;
  items: readonly FaqItem[];
};

export const faq = {
  eyebrow: "FAQ",
  title: "Frequently asked questions.",
  lead: "Short answers about age, compatibility, privacy, accounts and availability. Mingle is still being built, so the answers say what is true today.",
  note: "Nothing here is legal advice, and the privacy policy and terms haven’t been published yet.",
  controls: { expand: "Expand all", collapse: "Collapse all" },
  more: {
    title: "Can’t find your answer?",
    body: "The Help page covers the same ground by topic. Mingle doesn’t have a support contact yet, so there is nowhere to send a question.",
    link: { label: "Go to Help", href: "/help" },
  },

  categories: [
    {
      id: "age",
      title: "Age and eligibility",
      items: [
        {
          id: "age-who",
          question: "Who is Mingle for?",
          answer: [
            "Mingle is for adults aged 18 and over. Nobody under 18 may use it.",
          ],
        },
        {
          id: "age-under-18",
          question: "What happens if I enter a date of birth under 18?",
          answer: [
            "The sign-up form won’t continue. Your date isn’t stored, but a short-lived cookie is set in your browser to stop an immediate retry with a different date.",
            "That cookie is only a deterrent, because cookies can be cleared. It isn’t the real safeguard.",
          ],
        },
        {
          id: "age-proof",
          question: "Is typing my date of birth enough?",
          answer: [
            "No. A date you type in isn’t proof of age. Member features are designed to stay closed until further age checks are passed.",
            "The age-check service hasn’t been chosen yet, so that step doesn’t exist and member features stay closed.",
          ],
        },
        {
          id: "age-documents",
          question: "Will I have to share identity documents?",
          answer: [
            "That isn’t decided. The plan is to keep only the result of an age check and a reference to it, not identity documents or images. That plan hasn’t been built or reviewed.",
          ],
        },
      ],
    },
    {
      id: "compatibility",
      title: "Compatibility",
      items: [
        {
          id: "compat-how",
          question: "How does Mingle suggest people?",
          answer: [
            "Suggestions are designed to lean toward people whose answers and preferences overlap with yours: relationship intentions, core values, lifestyle, interests and communication preferences.",
            "Each suggestion is meant to give its reasons in plain words, so you can judge it yourself.",
          ],
        },
        {
          id: "compat-guarantee",
          question: "Can Mingle tell me who I’ll get along with?",
          answer: [
            "No. Compatibility is guidance about where to start. It can’t predict whether two people will get along, and Mingle can’t guarantee a match or a relationship.",
          ],
        },
        {
          id: "compat-score",
          question: "Will I see a compatibility score?",
          answer: [
            "No. You won’t see a compatibility percentage or score. Reasons in words are the intended design.",
            "The current preview still shows a number on its sample profiles. That doesn’t match the intended design.",
          ],
        },
        {
          id: "compat-sensitive",
          question: "Does Mingle use my religion, ethnicity, politics or health?",
          answer: [
            "No. Mingle doesn’t use religion, ethnicity, politics or health to work out compatibility, and the questions it asks don’t cover them.",
          ],
        },
      ],
    },
    {
      id: "privacy",
      title: "Privacy",
      items: [
        {
          id: "privacy-policy",
          question: "Where is the privacy policy?",
          answer: [
            "It hasn’t been published. It needs legal review, and it should be in place before accounts open.",
          ],
        },
        {
          id: "privacy-preview",
          question: "Where does my information go in the preview?",
          answer: [
            "Your preview profile and your actions are stored in your own browser. They aren’t sent to an account or shown to anyone, and clearing your browser’s site data removes them.",
          ],
        },
        {
          id: "privacy-photos",
          question: "What happens to photos?",
          answer: [
            "In the preview, photos are re-encoded in your browser, which removes location and camera details stored inside the file. They aren’t uploaded anywhere.",
            "How photos will be stored and checked for real members hasn’t been built yet.",
          ],
        },
        {
          id: "privacy-hide",
          question: "Can I hide my profile?",
          answer: [
            "The preview has a switch that hides your profile from suggestions. Controls for real members are planned.",
          ],
        },
      ],
    },
    {
      id: "accounts",
      title: "Accounts",
      items: [
        {
          id: "accounts-create",
          question: "Can I create an account?",
          answer: [
            "Not yet. Sign-up isn’t open. The form shows what it will ask for, but it can’t create an account, and it tells you so.",
          ],
        },
        {
          id: "accounts-email",
          question: "Will I need to confirm my email?",
          answer: [
            "That is planned as part of sign-up. No email service is connected yet, so nothing is sent today.",
          ],
        },
        {
          id: "accounts-password",
          question: "What will my password need?",
          answer: [
            "At least ten characters. Length matters more than special symbols, so there are no forced composition rules.",
          ],
        },
        {
          id: "accounts-exists",
          question: "Will sign-up tell me if an email is already registered?",
          answer: [
            "No. Sign-up and sign-in are designed so they don’t reveal whether an email address has an account, which stops other people checking.",
          ],
        },
      ],
    },
    {
      id: "availability",
      title: "Availability",
      items: [
        {
          id: "avail-open",
          question: "Is Mingle open?",
          answer: [
            "No. Accounts aren’t available and there are no members. What exists today is a preview built on sample data.",
          ],
        },
        {
          id: "avail-when",
          question: "When will it open?",
          answer: [
            "There is no launch date. Mingle will open only when its age checks, safety tools, privacy information and legal review are in place.",
          ],
        },
        {
          id: "avail-where",
          question: "Which countries and languages will it support?",
          answer: [
            "That hasn’t been decided. Mingle is written in English for now.",
          ],
        },
        {
          id: "avail-cost",
          question: "What will it cost?",
          answer: [
            "Pricing hasn’t been decided, and nothing can be bought.",
          ],
        },
        {
          id: "avail-support",
          question: "How do I contact support?",
          answer: [
            "There isn’t a published support contact yet. When a support process exists, the Help page will say how to use it.",
          ],
        },
      ],
    },
  ],
} as const satisfies {
  eyebrow: string;
  title: string;
  lead: string;
  note: string;
  controls: { expand: string; collapse: string };
  more: { title: string; body: string; link: SupportLink };
  categories: readonly FaqCategory[];
};

/** Flat list of every FAQ item, used by the accordion's deep links and by tests. */
const faqCategories: readonly FaqCategory[] = faq.categories;
export const faqItems: readonly FaqItem[] = faqCategories.flatMap((c) => c.items);
