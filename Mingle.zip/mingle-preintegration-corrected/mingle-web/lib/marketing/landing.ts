import { authLinks } from "@/lib/site";

/**
 * Copy for the landing sections added in F2.5: how it works, compatibility, values and
 * experience, trust and safety, and the closing call to action.
 *
 * Kept as plain data so tests can enforce the messaging rules (brief §6, §15): no guarantees,
 * no statistics, testimonials or member counts, no percentages, no sensitive traits used for
 * compatibility, and no safety feature described as live before it exists.
 *
 * Tense matters. Everything about the member journey is written as intent ("you’ll", "is
 * designed to"), because accounts, age assurance, reporting and moderation are not operational
 * yet (`getAuthBackend()` and `getAgeAssuranceProvider()` both return null).
 */

/* ------------------------------------------------------------------ how it works */

export type StepKey = "account" | "profile" | "discover" | "connect";

export const howItWorks = {
  id: "how-it-works",
  title: "How Mingle is designed to work",
  lead: "Four steps, from creating an account to starting a conversation. This is the journey we’re building toward.",
  steps: [
    {
      key: "account",
      title: "Create your account",
      body: "Sign up with your email and date of birth. Mingle is for adults aged 18 and over, so you’ll confirm your age and your email address before member features open.",
      details: ["Email and password", "Date of birth", "Email confirmation"],
    },
    {
      key: "profile",
      title: "Share who you are and what you’re looking for",
      body: "Build a profile with photos and a short bio, then say what you’re looking for. A few questions about values, lifestyle and communication help Mingle understand what matters to you.",
      details: ["Photos and a short bio", "Relationship intentions", "Values and lifestyle questions", "Who you’d like to meet"],
    },
    {
      key: "discover",
      title: "Discover people with shared ground",
      body: "Browse recommendations based on the preferences you chose to share. Each one is meant to come with plain reasons, such as interests you have in common, so you can decide for yourself.",
      details: ["Recommendations from your preferences", "Reasons shown in words", "Your choice on every profile"],
    },
    {
      key: "connect",
      title: "Connect when interest is mutual",
      body: "Let someone know you’re interested. When they’re interested in you too, you’ll be connected and can start a conversation with something to talk about.",
      details: ["Express interest", "Connect when it’s mutual", "Start a conversation"],
    },
  ],
  status: {
    title: "Where things stand",
    body: "Mingle is still being built. Accounts aren’t open yet and none of these steps can be completed on this site today. We’ll say so here when that changes.",
  },
  /** Link to the standalone page (F2.11), which labels each feature as preview, in development or planned. */
  more: { label: "See the full journey, feature by feature", href: "/how-it-works" },
} as const;

/* ------------------------------------------------------------------ compatibility */

export const compatibility = {
  id: "approach",
  title: "Chemistry is important. Understanding matters too.",
  lead: "Mingle is designed to help you find people you’re likely to understand, not to rank people or predict what will happen.",
  how: [
    {
      title: "You choose what to share",
      body: "You answer questions about what you’re looking for and how you live. You decide how much to say.",
    },
    {
      title: "Mingle looks for overlap",
      body: "Recommendations lean toward people whose answers and preferences have something in common with yours.",
    },
    {
      title: "You see why",
      body: "A recommendation is meant to show its reasons in plain words, so you can judge it yourself.",
    },
  ],
  signalsTitle: "What recommendations draw on",
  signals: [
    { label: "Relationship intentions", body: "The kind of relationship you’re open to." },
    { label: "Core values", body: "What you care about in people and in life." },
    { label: "Lifestyle", body: "How you like to spend your time and energy." },
    { label: "Interests", body: "The things you enjoy doing." },
    { label: "Communication preferences", body: "How you like to stay in touch." },
  ],
  figure: {
    caption: "Illustration of shared ground between two people. It isn’t a score and doesn’t show real members.",
    overlapLabel: "Shared ground",
  },
  disclaimerTitle: "Guidance, not a guarantee",
  disclaimer:
    "Compatibility is guidance to help you decide where to start. It can’t predict whether two people will get along, and Mingle can’t guarantee a match or a relationship. You won’t see a compatibility percentage or score.",
  excluded:
    "Mingle doesn’t use religion, ethnicity, politics or health to work out compatibility.",
} as const;

/* ------------------------------------------------------------------ values and experience */

export type ExperienceKey = "profiles" | "reasons" | "mutual" | "control";

export const values = {
  id: "values",
  title: "What we’re building toward",
  lead: "Mingle is shaped by a few values. They decide what we build and what we leave out.",
  principles: [
    {
      title: "Intention over volume",
      body: "A few relevant people are worth more than an endless feed. Discovery is designed to be deliberate.",
    },
    {
      title: "Clarity over guesswork",
      body: "Saying what you’re looking for early helps people avoid mismatched expectations.",
    },
    {
      title: "Respect by design",
      body: "Connection happens by mutual interest, not by unsolicited contact.",
    },
    {
      title: "Your information, your choice",
      body: "You decide what to share. We ask only for what the experience needs.",
    },
  ],
  experienceTitle: "The experience we’re aiming for",
  experience: [
    {
      key: "profiles",
      title: "Profiles with room to be yourself",
      body: "Photos, a bio and your answers sit together, so a profile says more than a first glance.",
    },
    {
      key: "reasons",
      title: "Recommendations that explain themselves",
      body: "You see the shared ground behind a suggestion, in words, without a number attached.",
    },
    {
      key: "mutual",
      title: "Conversations by mutual interest",
      body: "You connect when both people are interested, then start from what you have in common.",
    },
    {
      key: "control",
      title: "Controls that stay with you",
      body: "You’re meant to be able to manage your preferences and who can see your profile.",
    },
  ],
  note: "This describes the experience Mingle is being designed to offer. These features are in development and aren’t available to use yet.",
} as const;

/* ------------------------------------------------------------------ trust and safety */

export type TrustKey = "discovery" | "privacy" | "respect";

export const trust = {
  id: "trust-and-safety",
  title: "Your comfort comes first.",
  lead: "Meaningful connection needs trust. This is what we’re designing for, and how far along it is.",
  adult: {
    mark: "18+",
    title: "Adults only",
    body: "Mingle is for adults aged 18 and over. You’ll give your date of birth when you sign up, and member features are designed to stay closed until age and email checks are passed. Further age checks are planned, so the date of birth you enter is only the first step.",
  },
  pillars: [
    {
      key: "discovery",
      title: "Responsible discovery",
      points: [
        "Recommendations come from preferences you choose to share.",
        "Sensitive traits aren’t used to work out compatibility.",
        "Messaging is intended for people who have connected by mutual interest.",
      ],
    },
    {
      key: "privacy",
      title: "Privacy",
      points: [
        "We aim to collect only what the experience needs.",
        "For age checks, the plan is to keep the result and a reference, not identity documents or images.",
        "Controls over your profile’s visibility are planned.",
      ],
    },
    {
      key: "respect",
      title: "Respectful interaction",
      points: [
        "Community standards are being written for every member.",
        "Blocking and reporting are being designed.",
        "Moderation and support processes are being planned.",
      ],
    },
  ],
  status: {
    title: "Not live yet",
    lead: "We’ll describe a safety feature as available only once it works.",
    items: [
      { label: "Account sign-up", state: "Not open yet" },
      { label: "Age assurance provider", state: "Not chosen yet" },
      { label: "Blocking and reporting", state: "In development" },
      { label: "Moderation and support", state: "Being planned" },
      { label: "Profile verification", state: "Being planned" },
    ],
  },
  legalNote:
    "Our safety centre, community guidelines and privacy information are drafts that haven’t been published or legally reviewed.",
  links: [
    { label: "Safety centre (in progress)", href: "/safety" },
    { label: "Community guidelines (in progress)", href: "/community-guidelines" },
  ],
} as const;

/* ------------------------------------------------------------------ final call to action */

export const finalCta = {
  id: "final-cta",
  title: "Make room for something meaningful.",
  body: "Your next connection doesn’t need to begin with endless scrolling. Start with who you are, what matters to you and the people you’d genuinely like to meet.",
  adultLine: "Mingle is for adults aged 18 and over.",
  primary: authLinks.getStarted,
  signIn: authLinks.signIn,
  safety: { label: "Read about safety", href: "/#trust-and-safety" },
} as const;
