/**
 * Age-assurance provider boundary. The provider is an OPEN decision (brief §17), so nothing
 * here names one. Implement this interface once one is chosen; until then `null` means
 * "not configured" and member access stays closed (see access.ts).
 *
 * Data minimisation (brief §6): persist only the outcome and the provider's reference
 * (public.verification_records). Never persist identity documents or images.
 */
export type AgeAssuranceResult = {
  reference: string;
  outcome: "passed" | "failed" | "error";
};

export interface AgeAssuranceProvider {
  readonly id: string;
  /** Begin a check for an account; the member is sent to `redirectUrl`. */
  startCheck(input: {
    accountId: string;
    returnUrl: string;
  }): Promise<{ redirectUrl: string; reference: string }>;
  /** Verify the provider's signature, then reduce its payload to the minimal result. */
  readResult(input: { body: string; signature: string }): Promise<AgeAssuranceResult>;
}

export function getAgeAssuranceProvider(): AgeAssuranceProvider | null {
  return null;
}
