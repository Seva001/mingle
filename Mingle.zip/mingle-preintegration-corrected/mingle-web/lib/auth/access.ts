/**
 * The single rule for "may this account use member features?" (brief §7, §15).
 * Pure and fail-closed: anything not explicitly satisfied is denied. There is deliberately
 * no flag to switch age assurance off. Enforce this on the server and in the database, never
 * only by hiding UI.
 */
export type AccountStatus = "pending" | "active" | "suspended" | "blocked_underage" | "deleted";
export type AgeAssuranceOutcome = "not_started" | "pending" | "passed" | "failed" | "error";

export type AccessSubject = {
  emailVerified: boolean;
  status: AccountStatus;
  ageAssurance: AgeAssuranceOutcome;
};

export type DenyReason =
  | "signed_out"
  | "email_unverified"
  | "age_assurance_required"
  | "age_assurance_failed"
  | "account_blocked"
  | "eligibility_pending";

export type AccessDecision =
  | { allowed: true }
  /** Blocked destinations go to /sign-in: the caller must also end the session. */
  | { allowed: false; reason: DenyReason; destination: "/sign-in" | "/verify" | "/eligibility" };

export function decideMemberAccess(subject: AccessSubject | null): AccessDecision {
  if (!subject) return { allowed: false, reason: "signed_out", destination: "/sign-in" };

  if (
    subject.status === "blocked_underage" ||
    subject.status === "suspended" ||
    subject.status === "deleted"
  ) {
    return { allowed: false, reason: "account_blocked", destination: "/sign-in" };
  }
  if (subject.ageAssurance === "failed") {
    return { allowed: false, reason: "age_assurance_failed", destination: "/sign-in" };
  }
  if (!subject.emailVerified) {
    return { allowed: false, reason: "email_unverified", destination: "/verify" };
  }
  if (subject.ageAssurance !== "passed") {
    return { allowed: false, reason: "age_assurance_required", destination: "/verify" };
  }
  if (subject.status === "pending") {
    return { allowed: false, reason: "eligibility_pending", destination: "/eligibility" };
  }
  if (subject.status !== "active") {
    return { allowed: false, reason: "account_blocked", destination: "/sign-in" };
  }
  return { allowed: true };
}
