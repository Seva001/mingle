import type { Metadata } from "next";
import Link from "next/link";
import { Card } from "@/components/ui/card";
import { FormNotice } from "@/components/forms/form-notice";

export const metadata: Metadata = { title: "Adult eligibility" };

export default function EligibilityPage() {
  return (
    <div className="w-full max-w-md">
      <h1 className="font-display text-headline">Adult eligibility</h1>
      <p className="mt-3 text-lead text-muted">
        Mingle is strictly for adults aged 18 and over.
      </p>
      <Card className="mt-8 flex flex-col gap-5">
        <FormNotice tone="info">
          Age assurance is not connected in this preview. Access to member features remains
          unavailable until an appropriate verification process is implemented.
        </FormNotice>
        <div>
          <h2 className="text-body font-semibold">A date of birth is not verification</h2>
          <p className="mt-2 text-caption text-muted">
            The date entered during sign-up is a declaration only. It does not prove someone is
            18 or older, and this page does not mark anyone as verified.
          </p>
        </div>
        <p className="text-caption text-muted">
          Read more in the <Link href="/help#age-eligibility" className="font-semibold text-foreground underline">age and eligibility help section</Link>.
        </p>
      </Card>
    </div>
  );
}
