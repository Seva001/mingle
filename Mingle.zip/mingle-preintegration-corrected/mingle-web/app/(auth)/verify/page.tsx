import type { Metadata } from "next";
import { Card } from "@/components/ui/card";
import { VerificationStatus } from "@/components/forms/verification-status";

export const metadata: Metadata = { title: "Verify your email" };

// Static explanation only. Per-account status (email confirmed, age check outcome) comes from
// the session once Supabase is connected; nothing here pretends to know it.
export default function Page() {
  return (
    <div className="w-full max-w-md">
      <h1 className="font-display text-headline">Two quick checks</h1>
      <p className="mt-3 text-lead text-muted">
        Mingle is adults-only, so access opens after both.
      </p>
      <Card className="mt-8">
        <ol className="flex flex-col gap-6">
          <li>
            <h2 className="text-body font-semibold">1. Confirm your email</h2>
            <p className="mt-1 text-caption text-muted">
              Mingle will send a confirmation link once its email service is connected.
            </p>
          </li>
          <li>
            <h2 className="text-body font-semibold">2. Age check</h2>
            <p className="mt-1 text-caption text-muted">
              A short check with a specialist provider. We aim to keep only its outcome, not your
              documents.
            </p>
          </li>
        </ol>
        <VerificationStatus />
      </Card>
    </div>
  );
}
