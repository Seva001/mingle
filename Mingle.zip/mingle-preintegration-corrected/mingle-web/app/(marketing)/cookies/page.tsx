import type { Metadata } from "next";
import { LegalDocument } from "@/components/marketing/legal-document";

export const metadata: Metadata = { title: "Cookie information" };

export default function Page() {
  return <LegalDocument title="Cookie and browser storage information" lead="An explanation of browser-side storage used by this development preview." sections={[
    { title: "Current preview behaviour", paragraphs: ["This frontend uses browser storage for limited demonstration features such as the local profile, discovery actions and theme preference. These are not authentication records and do not create a server account.", "The current project does not provide a complete cookie-consent manager or a production analytics/advertising consent system. Do not interpret this page as a full inventory of production cookies or third-party trackers."] },
    { title: "Essential and optional storage", paragraphs: ["Before launch, the operator must inventory cookies, local storage, session storage, embedded services and any similar technologies. Each item must have a documented purpose, duration, provider and consent requirement for the markets served."] },
    { title: "Managing browser data", paragraphs: ["You can clear site data through your browser settings. Doing so may remove this preview’s local profile, discovery choices and theme preference. This does not delete a server account because this frontend preview is not connected to one."] },
    { title: "Consent controls", paragraphs: ["A production preference centre, where legally required, must be implemented and tested before any non-essential tracking is enabled. No consent preference is saved by this page."] },
  ]} />;
}
