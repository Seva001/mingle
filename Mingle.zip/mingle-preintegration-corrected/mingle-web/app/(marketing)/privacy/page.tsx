import type { Metadata } from "next";
import { LegalDocument } from "@/components/marketing/legal-document";

export const metadata: Metadata = { title: "Privacy policy — draft" };

export default function Page() {
  return <LegalDocument title="Privacy policy" lead="An outline of the privacy information Mingle must provide before any real member accounts are opened." sections={[
    { title: "Who operates Mingle", paragraphs: ["The legal name, registered address and contact details of the Mingle operator must be inserted here before launch. This information has not yet been supplied in the project materials."] },
    { title: "Information we may need", paragraphs: ["The final notice must describe each category of information collected, why it is needed, whether it is optional, and the lawful basis for processing. It must distinguish account details, profile content, safety reports, device and diagnostic data, and age-assurance information.", "The product is intended strictly for adults aged 18 and over. A date-of-birth declaration by itself is not age verification. The operator must document the selected age-assurance method, provider, data flows, retention and appeal process before launch."] },
    { title: "How information is used and shared", paragraphs: ["The final notice must identify each purpose, the service providers or recipient categories involved, international transfers, and any advertising or analytics use. Do not assume that data is shared with or withheld from a category of recipient until the production architecture is confirmed."] },
    { title: "Retention, security and your choices", paragraphs: ["The operator must define retention periods, deletion schedules, security controls, access and correction procedures, account closure, export requests and complaint handling. These controls are not implemented by this frontend preview."] },
    { title: "Contact and complaints", paragraphs: ["Insert a monitored privacy contact and the applicable regulator or complaint route after the operator and launch jurisdictions are confirmed. The current contact form is a local preview and does not deliver messages."] },
  ]} />;
}
