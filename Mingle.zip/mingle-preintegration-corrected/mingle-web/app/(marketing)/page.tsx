import type { Metadata } from "next";
import { Compatibility } from "@/components/marketing/compatibility";
import { Experience } from "@/components/marketing/experience";
import { FinalCta } from "@/components/marketing/final-cta";
import { Hero } from "@/components/marketing/hero";
import { HowItWorks } from "@/components/marketing/how-it-works";
import { Introduction } from "@/components/marketing/introduction";
import { TrustSafety } from "@/components/marketing/trust-safety";

export const metadata: Metadata = {
  title: { absolute: "Mingle: A little more intention. A lot more connection." },
  description:
    "Meet people who share your values, understand your lifestyle and are looking for something meaningful. For adults 18+.",
};

export default function HomePage() {
  const accountsAvailable = false;

  return (
    <>
      <Hero accountsAvailable={accountsAvailable} />
      <Introduction />
      <HowItWorks />
      <Compatibility />
      <Experience />
      <TrustSafety />
      <FinalCta accountsAvailable={accountsAvailable} />
    </>
  );
}
