import { redirect } from "next/navigation";
import { MemberShell } from "@/components/layout/member-shell";
import { clearMemberSession, getMemberAccess } from "@/lib/auth/member-access";

export default async function MemberLayout({ children }: { children: React.ReactNode }) {
  const access = await getMemberAccess();
  if (!access.allowed) {
    if (access.reason === "account_blocked" || access.reason === "age_assurance_failed") {
      await clearMemberSession();
    }
    redirect(access.destination);
  }
  return <MemberShell>{children}</MemberShell>;
}
