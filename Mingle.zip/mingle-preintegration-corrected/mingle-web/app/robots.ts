import type { MetadataRoute } from "next";

// Disallow everything until launch gates (age assurance, safety ops, legal review) are met.
export default function robots(): MetadataRoute.Robots {
  return { rules: { userAgent: "*", disallow: "/" } };
}
