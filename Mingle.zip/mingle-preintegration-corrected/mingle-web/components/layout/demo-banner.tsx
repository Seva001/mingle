import { FlaskConical } from "lucide-react";

/** Brief §15: demo data must be clearly labelled. Shown on every member screen until Phase 2 ships. */
export function DemoBanner() {
  return (
    <p
      role="note"
      className="mb-6 flex items-start gap-3 rounded-control border border-line bg-surface p-4 text-caption text-muted"
    >
      <FlaskConical className="mt-0.5 size-4 shrink-0" aria-hidden />
      <span>
        <span className="font-semibold text-foreground">Demo mode.</span> Anything you enter is stored
        only in this browser and isn’t shared. There are no real members here.
      </span>
    </p>
  );
}
