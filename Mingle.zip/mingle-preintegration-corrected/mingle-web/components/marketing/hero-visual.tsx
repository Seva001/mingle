import { HeartHandshake } from "lucide-react";

const signals = [
  { label: "Relationship intentions", pos: "left-4 top-[14%]" },
  { label: "Core values", pos: "right-4 top-[26%]" },
  { label: "Lifestyle", pos: "left-6 top-[52%]" },
  { label: "Interests", pos: "right-6 top-[64%]" },
];

/**
 * Abstract illustration of the idea (overlapping lives, shared signals).
 * Deliberately contains no people, names, scores or counts: nothing here can be mistaken
 * for a real member (brief §15).
 */
export function HeroVisual() {
  return (
    <figure className="relative mx-auto w-full max-w-md">
      <div
        className="relative aspect-[4/5] overflow-hidden rounded-card shadow-card"
        style={{ background: "linear-gradient(160deg, #2b2040 0%, #5a2f3a 52%, #c2693a 100%)" }}
        aria-hidden
      >
        <div className="absolute top-[24%] left-[8%] aspect-square w-[62%] rounded-full bg-brand opacity-90 mix-blend-screen" />
        <div className="absolute top-[30%] right-[8%] aspect-square w-[56%] rounded-full border-2 border-white/70" />
        <div className="absolute inset-0" style={{ background: "var(--photo-scrim)" }} />

        {signals.map((s) => (
          <span
            key={s.label}
            className={`glass-photo absolute rounded-full px-3.5 py-1.5 text-caption font-medium ${s.pos}`}
          >
            {s.label}
          </span>
        ))}

        <div className="absolute inset-x-0 bottom-0 flex flex-col gap-3 p-5">
          <span className="glass-photo inline-flex w-fit items-center gap-1.5 rounded-full px-3 py-1.5 text-caption font-medium">
            <HeartHandshake className="size-3.5 text-brand" aria-hidden />
            Similar intentions and lifestyle
          </span>
        </div>
      </div>
      <figcaption className="mt-3 text-center text-caption text-muted">
        Illustration of the experience, not a real profile.
      </figcaption>
    </figure>
  );
}
