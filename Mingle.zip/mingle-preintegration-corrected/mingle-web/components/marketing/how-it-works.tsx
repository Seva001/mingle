import Link from "next/link";
import { ArrowRight, Info } from "lucide-react";
import { Section } from "@/components/marketing/section";
import { Tag } from "@/components/ui/tag";
import { howItWorks } from "@/lib/marketing/landing";

/**
 * Landing "How it works" (F2.5). Static server component. The steps are a real sequence, so an
 * ordered list with visible step numbers is the honest structure. Written as intent: nothing
 * here claims sign-up, profiles or connections work today (brief §15).
 */
export function HowItWorks() {
  const { status } = howItWorks;

  return (
    <Section
      id={howItWorks.id}
      title={howItWorks.title}
      intro={howItWorks.lead}
      tone="strong"
    >
      <ol className="divide-y divide-line border-y border-line">
        {howItWorks.steps.map((step, index) => (
          <li
            key={step.key}
            className="grid gap-5 py-8 md:grid-cols-[minmax(0,5fr)_minmax(0,7fr)] md:gap-12 md:py-10"
          >
            <div className="flex min-w-0 items-start gap-4">
              <span
                aria-hidden
                className="flex size-11 shrink-0 items-center justify-center rounded-full bg-brand font-semibold text-on-brand"
              >
                {index + 1}
              </span>
              <h3 className="text-title font-semibold text-balance">
                <span className="sr-only">Step {index + 1}: </span>
                {step.title}
              </h3>
            </div>
            <div className="min-w-0">
              <p className="max-w-prose text-body text-foreground/70">{step.body}</p>
              <ul className="mt-5 flex flex-wrap gap-2">
                {step.details.map((detail) => (
                  <li key={detail}>
                    <Tag>{detail}</Tag>
                  </li>
                ))}
              </ul>
            </div>
          </li>
        ))}
      </ol>

      <p className="mt-8 flex max-w-3xl items-start gap-3 rounded-control border border-line bg-surface p-4 text-caption text-foreground/70">
        <Info className="mt-0.5 size-4 shrink-0" aria-hidden />
        <span>
          <span className="font-semibold text-foreground">{status.title}. </span>
          {status.body}
        </span>
      </p>

      <p className="mt-4">
        <Link
          href={howItWorks.more.href}
          className="inline-flex min-h-11 items-center gap-2 font-semibold text-foreground underline underline-offset-4"
        >
          {howItWorks.more.label}
          <ArrowRight className="size-4" aria-hidden />
        </Link>
      </p>
    </Section>
  );
}
