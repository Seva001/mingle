"use client";

import { useEffect, useMemo, useState } from "react";
import Link from "next/link";
import { Bookmark, Check, Heart, MapPin, RotateCcw, SlidersHorizontal, X, UserRound, Filter } from "lucide-react";
import { useDemoProfile } from "@/components/profile/use-demo-profile";
import { Button } from "@/components/ui/button";
import { DISCOVERY_FIXTURES } from "@/lib/discovery/fixtures";
import { calculateCompatibility, getRecommendations } from "@/lib/discovery/engine";
import { clearDiscoveryActions, readDiscoveryActions, setDiscoveryAction, subscribeDiscoveryActions } from "@/lib/discovery/demo-store";
import type { DiscoveryActions, DiscoveryCandidate } from "@/lib/discovery/types";
import { INTENTIONS } from "@/lib/profile/options";
import { Field } from "@/components/ui/field";

const accentClasses: Record<DiscoveryCandidate["accent"], string> = {
  violet: "from-violet-950 via-purple-800 to-fuchsia-700",
  rose: "from-rose-950 via-rose-800 to-orange-700",
  amber: "from-amber-950 via-orange-800 to-yellow-700",
  blue: "from-slate-950 via-blue-900 to-cyan-700",
  green: "from-emerald-950 via-teal-800 to-lime-700",
};

function ProfileArtwork({ candidate }: { candidate: DiscoveryCandidate }) {
  return (
    <div className={`relative flex min-h-[24rem] items-center justify-center overflow-hidden bg-gradient-to-br ${accentClasses[candidate.accent]}`}>
      <div aria-hidden className="absolute -right-14 -top-20 size-72 rounded-full border border-white/10" />
      <div aria-hidden className="absolute -bottom-24 -left-16 size-80 rounded-full border border-white/10" />
      <div className="relative flex size-36 items-center justify-center rounded-full border border-white/25 bg-white/10 font-display text-6xl text-white shadow-2xl backdrop-blur-sm">
        {candidate.displayName.slice(0, 1)}
      </div>
      <span className="absolute left-5 top-5 rounded-full border border-white/20 bg-black/25 px-3 py-1.5 text-xs font-semibold text-white backdrop-blur">
        Synthetic demo profile
      </span>
      <div className="absolute inset-x-0 bottom-0 bg-gradient-to-t from-black/90 via-black/45 to-transparent p-6 pt-24 text-white">
        <p className="mb-2 flex items-center gap-1.5 text-sm text-white/75"><MapPin className="size-4" aria-hidden />{candidate.city}, {candidate.country}</p>
        <h2 className="font-display text-3xl font-semibold tracking-tight">{candidate.displayName}, {candidate.age}</h2>
      </div>
    </div>
  );
}

export function DiscoveryExperience() {
  const member = useDemoProfile();
  const [actions, setActions] = useState<DiscoveryActions>({});
  const [filter, setFilter] = useState<"all" | "shared">("all");
  const [search, setSearch] = useState("");
  const [notice, setNotice] = useState("");
  const [advancedOpen, setAdvancedOpen] = useState(false);
  const [ageMin, setAgeMin] = useState("18");
  const [ageMax, setAgeMax] = useState("60");
  const [city, setCity] = useState("");
  const [intention, setIntention] = useState("all");
  const [interest, setInterest] = useState("");
  const [selectedCandidate, setSelectedCandidate] = useState<DiscoveryCandidate | null>(null);
  const [pendingBlock, setPendingBlock] = useState<DiscoveryCandidate | null>(null);

  useEffect(() => {
    setActions(readDiscoveryActions());
    return subscribeDiscoveryActions(() => setActions(readDiscoveryActions()));
  }, []);

  const recommendations = useMemo(() => {
    if (!member) return [];
    const excluded = Object.entries(actions).filter(([, action]) => action === "passed" || action === "liked" || action === "blocked").map(([id]) => id);
    return getRecommendations(member, DISCOVERY_FIXTURES, excluded)
      .map((candidate) => ({ candidate, compatibility: calculateCompatibility(member, candidate) }))
      .filter(({ compatibility }) => filter === "all" || compatibility.sharedInterests.length > 0)
      .filter(({ candidate }) => {
        const needle = search.trim().toLocaleLowerCase();
        return !needle || [candidate.displayName, candidate.city, candidate.country, ...candidate.interests].some((value) => value.toLocaleLowerCase().includes(needle));
      })
      .filter(({ candidate }) => candidate.age >= Number(ageMin || 18) && candidate.age <= Number(ageMax || 99))
      .filter(({ candidate }) => !city.trim() || `${candidate.city} ${candidate.country}`.toLowerCase().includes(city.trim().toLowerCase()))
      .filter(({ candidate }) => intention === "all" || candidate.intention === intention)
      .filter(({ candidate }) => !interest.trim() || candidate.interests.some((item) => item.toLowerCase().includes(interest.trim().toLowerCase())))
      .sort((a, b) => b.compatibility.score - a.compatibility.score);
  }, [member, actions, filter, search, ageMin, ageMax, city, intention, interest]);

  const saved = useMemo(() => DISCOVERY_FIXTURES.filter((candidate) => actions[candidate.id] === "saved"), [actions]);

  function act(candidate: DiscoveryCandidate, action: "liked" | "passed" | "saved" | "blocked") {
    if (action === "blocked") { setPendingBlock(candidate); return; }
    const next = action === "saved" && actions[candidate.id] === "saved" ? null : action;
    const ok = setDiscoveryAction(candidate.id, next);
    if (!ok) {
      setNotice("Your browser could not save this demo action. Check local storage and try again.");
      return;
    }
    setNotice(action === "liked" ? "Interest saved in this browser demo. This does not notify or connect to anyone." : action === "passed" ? "Profile passed in this browser demo." : next ? "Saved to your demo list." : "Removed from your saved demo list.");
  }

  if (!member) {
    return <section className="rounded-card border border-line bg-surface p-6"><p className="text-sm text-muted">Loading your local demo profile…</p></section>;
  }

  const ready = Boolean(member.displayName.trim() && member.age && member.gender && member.interestedIn.length && member.intention && member.interests.length >= 3);

  if (!ready) {
    return (
      <section className="rounded-card border border-line bg-surface p-6 md:p-8">
        <p className="text-xs font-bold uppercase tracking-[0.18em] text-brand">Your next step</p>
        <h2 className="mt-3 font-display text-2xl font-semibold">Finish your demo profile first.</h2>
        <p className="mt-2 max-w-xl text-sm leading-6 text-muted">Discovery needs your age, gender, who you would like to meet, relationship intention and at least three interests to demonstrate mutual-preference filtering.</p>
        <Button className="mt-6" onClick={() => { window.location.href = "/onboarding"; }}>Complete profile</Button>
      </section>
    );
  }

  return (
    <div className="space-y-6">
      <section className="flex flex-col justify-between gap-4 sm:flex-row sm:items-end">
        <div>
          <p className="text-xs font-bold uppercase tracking-[0.18em] text-brand">Discover intentionally</p>
          <h2 className="mt-2 font-display text-3xl font-semibold tracking-tight">People worth getting to know.</h2>
          <p className="mt-2 max-w-xl text-sm leading-6 text-muted">These are synthetic profiles for testing the experience. Compatibility is an exploratory explanation, not a prediction.</p>
        </div>
        <div className="flex flex-wrap gap-2">
          <button type="button" onClick={() => setFilter("all")} aria-pressed={filter === "all"} className={`rounded-full border px-4 py-2 text-sm font-semibold ${filter === "all" ? "border-foreground bg-foreground text-background" : "border-line bg-surface text-muted"}`}>For you</button>
          <button type="button" onClick={() => setFilter("shared")} aria-pressed={filter === "shared"} className={`rounded-full border px-4 py-2 text-sm font-semibold ${filter === "shared" ? "border-foreground bg-foreground text-background" : "border-line bg-surface text-muted"}`}>Shared interests</button>
        </div>
      </section>

      <div className="flex flex-col gap-3 sm:flex-row sm:items-end">
        <div className="min-w-0 flex-1"><Field label="Search profiles" placeholder="Name, city or interest" value={search} onChange={(event) => setSearch(event.target.value)} /></div>
        <Button variant="secondary" onClick={() => setAdvancedOpen((open) => !open)} aria-expanded={advancedOpen} aria-controls="advanced-discovery-filters"><Filter className="size-4" aria-hidden />{advancedOpen ? "Hide filters" : "Advanced filters"}</Button>
      </div>

      {advancedOpen ? <section id="advanced-discovery-filters" className="rounded-card border border-line bg-surface p-5" aria-label="Advanced discovery filters">
        <div className="flex items-center justify-between gap-3"><div><h3 className="font-semibold">Refine your discovery</h3><p className="mt-1 text-xs text-muted">Filters apply to synthetic profiles in this browser preview.</p></div><button type="button" onClick={() => { setAgeMin("18"); setAgeMax("60"); setCity(""); setIntention("all"); setInterest(""); setSearch(""); setFilter("all"); }} className="text-xs font-semibold underline underline-offset-4">Clear all</button></div>
        <div className="mt-4 grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
          <Field label="Minimum age" inputMode="numeric" value={ageMin} onChange={(event) => setAgeMin(String(Math.max(18, Number(event.target.value.replace(/[^0-9]/g, "") || 18))))} />
          <Field label="Maximum age" inputMode="numeric" value={ageMax} onChange={(event) => setAgeMax(String(Math.max(18, Number(event.target.value.replace(/[^0-9]/g, "") || 18))))} />
          <Field label="Location" placeholder="City or country" value={city} onChange={(event) => setCity(event.target.value)} />
          <div><label htmlFor="discovery-intention" className="mb-1.5 block text-caption font-semibold">Relationship intention</label><select id="discovery-intention" value={intention} onChange={(event) => setIntention(event.target.value)} className="h-12 w-full rounded-control border border-line bg-background px-4 text-sm text-foreground"><option value="all">Any intention</option>{INTENTIONS.map((item) => <option key={item.value} value={item.value}>{item.label}</option>)}</select></div>
          <Field label="Interest" placeholder="e.g. Travel" value={interest} onChange={(event) => setInterest(event.target.value)} />
        </div>
        {Number(ageMin) > Number(ageMax) ? <p role="alert" className="mt-3 text-xs text-danger">Minimum age must not be greater than maximum age.</p> : null}
      </section> : null}

      {notice ? <p role="status" className="rounded-control border border-line bg-surface p-3 text-sm text-muted">{notice}</p> : null}

      {pendingBlock ? <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 p-4" role="presentation" onMouseDown={(event) => { if (event.target === event.currentTarget) setPendingBlock(null); }}>
        <section role="dialog" aria-modal="true" aria-labelledby="block-confirm-title" onKeyDown={(event) => { if (event.key === "Escape") setPendingBlock(null); if (event.key === "Tab") { const controls = event.currentTarget.querySelectorAll<HTMLElement>('button:not([disabled])'); const first = controls[0]; const last = controls[controls.length - 1]; if (event.shiftKey && document.activeElement === first) { event.preventDefault(); last?.focus(); } else if (!event.shiftKey && document.activeElement === last) { event.preventDefault(); first?.focus(); } } }} className="w-full max-w-md rounded-card border border-line bg-surface p-6 shadow-card">
          <h2 id="block-confirm-title" className="font-display text-xl font-semibold">Hide this demo profile?</h2>
          <p className="mt-2 text-sm leading-6 text-muted">{pendingBlock.displayName} will be hidden from this browser's synthetic discovery preview. This does not block a real person or affect any account.</p>
          <div className="mt-5 flex flex-wrap justify-end gap-2"><Button autoFocus variant="secondary" onClick={() => setPendingBlock(null)}>Cancel</Button><Button variant="danger" onClick={() => { const candidate = pendingBlock; const ok = setDiscoveryAction(candidate.id, "blocked"); setPendingBlock(null); setNotice(ok ? "Synthetic profile hidden from this browser preview only." : "Could not update the local preview. Check browser storage."); }}>Hide profile</Button></div>
        </section>
      </div> : null}

      <div className="grid gap-6 lg:grid-cols-[minmax(0,1fr)_18rem]">
        <div className="space-y-5">
          {selectedCandidate ? <section className="rounded-card border border-line bg-surface p-5" aria-labelledby="profile-detail-title">
            <div className="flex items-start justify-between gap-3"><div><p className="text-xs font-bold uppercase tracking-[0.16em] text-brand">Profile details · synthetic demo</p><h3 id="profile-detail-title" className="mt-2 font-display text-2xl font-semibold">{selectedCandidate.displayName}, {selectedCandidate.age}</h3><p className="mt-1 text-sm text-muted">{selectedCandidate.city}, {selectedCandidate.country}</p></div><Button variant="ghost" size="sm" onClick={() => setSelectedCandidate(null)} aria-label="Close profile details"><X className="size-4" aria-hidden /></Button></div>
            <p className="mt-4 text-sm leading-6">{selectedCandidate.bio}</p>
            <div className="mt-4"><p className="text-xs font-semibold uppercase tracking-wider text-muted">Interests</p><ul className="mt-2 flex flex-wrap gap-2">{selectedCandidate.interests.map((item) => <li key={item} className="rounded-full border border-line px-3 py-1.5 text-xs text-muted">{item}</li>)}</ul></div>
            <div className="mt-4 grid gap-3 border-t border-line pt-4 sm:grid-cols-2"><div><p className="text-xs text-muted">Relationship intention</p><p className="mt-1 text-sm font-medium">{INTENTIONS.find((item) => item.value === selectedCandidate.intention)?.label ?? "Not specified"}</p></div><div><p className="text-xs text-muted">Profile status</p><p className="mt-1 text-sm font-medium">Fictional interface fixture</p></div></div>
            <p className="mt-4 text-xs leading-5 text-muted">This profile is synthetic and does not represent a real person. Its compatibility signals are exploratory and are not a prediction.</p>
          </section> : null}
          {recommendations.length ? recommendations.map(({ candidate, compatibility }) => {
            const intention = INTENTIONS.find((item) => item.value === candidate.intention)?.label;
            return (
              <article key={candidate.id} className="overflow-hidden rounded-card border border-line bg-surface shadow-card">
                <ProfileArtwork candidate={candidate} />
                <div className="space-y-5 p-5 md:p-6">
                  <div className="flex flex-wrap items-center justify-between gap-3">
                    <div>
                      <p className="text-xs font-bold uppercase tracking-[0.16em] text-brand">Compatibility signals</p>
                      <p className="mt-1 text-2xl font-semibold tabular-nums">{compatibility.score}<span className="text-base text-muted">/100</span></p>
                    </div>
                    <span className="rounded-full border border-line px-3 py-1.5 text-xs text-muted">Exploratory, not predictive</span>
                  </div>
                  <p className="text-sm leading-6 text-muted">{candidate.bio}</p>
                  {intention ? <p className="text-sm"><span className="text-muted">Looking for: </span><span className="font-medium">{intention}</span></p> : null}
                  <div>
                    <p className="mb-2 text-xs font-semibold uppercase tracking-wider text-muted">What you have in common</p>
                    <ul className="flex flex-wrap gap-2">
                      {compatibility.explanation.map((item) => <li key={item} className="rounded-full bg-foreground/5 px-3 py-1.5 text-xs">{item}</li>)}
                    </ul>
                  </div>
                  <div>
                    <p className="mb-2 text-xs font-semibold uppercase tracking-wider text-muted">Interests</p>
                    <ul className="flex flex-wrap gap-2">{candidate.interests.map((interest) => <li key={interest} className="rounded-full border border-line px-3 py-1.5 text-xs text-muted">{interest}</li>)}</ul>
                  </div>
                  <div className="grid grid-cols-2 gap-2 border-t border-line pt-4 sm:grid-cols-5">
                    <Button variant="secondary" onClick={() => setSelectedCandidate(candidate)}><UserRound className="size-4" aria-hidden />Details</Button>
                    <Button variant="secondary" onClick={() => act(candidate, "passed")}><X className="size-4" aria-hidden />Pass</Button>
                    <Button variant="secondary" onClick={() => act(candidate, "saved")}><Bookmark className="size-4" aria-hidden />{actions[candidate.id] === "saved" ? "Saved" : "Save"}</Button>
                    <Button onClick={() => act(candidate, "liked")}><Heart className="size-4" aria-hidden />Interested</Button>
                    <Button variant="ghost" onClick={() => act(candidate, "blocked")}>Block</Button>
                  </div>
                  <Link href="/report" className="inline-block text-caption font-semibold underline underline-offset-4">Report a concern</Link>
                </div>
              </article>
            );
          }) : (
            <section className="rounded-card border border-line bg-surface p-7 text-center">
              <SlidersHorizontal className="mx-auto size-7 text-muted" aria-hidden />
              <h3 className="mt-3 font-display text-xl font-semibold">No profiles match this view.</h3>
              <p className="mx-auto mt-2 max-w-md text-sm leading-6 text-muted">Try another name, city or interest, or clear your search and filters to see more synthetic demo profiles.</p>
              <div className="mt-5 flex flex-wrap justify-center gap-2"><Button variant="secondary" onClick={() => setSearch("")}>Clear search</Button><Button variant="secondary" onClick={() => { clearDiscoveryActions(); setNotice("Demo discovery actions have been reset."); }}><RotateCcw className="size-4" aria-hidden />Reset demo</Button></div>
            </section>
          )}
        </div>

        <aside className="space-y-4">
          <section className="rounded-card border border-line bg-surface p-5">
            <p className="text-xs font-bold uppercase tracking-[0.16em] text-muted">Your discovery</p>
            <p className="mt-3 font-display text-3xl font-semibold tabular-nums">{recommendations.length}</p>
            <p className="mt-1 text-sm text-muted">Eligible synthetic profiles in this view</p>
            <div className="my-4 border-t border-line" />
            <p className="font-display text-2xl font-semibold tabular-nums">{saved.length}</p>
            <p className="mt-1 text-sm text-muted">Saved for later</p>
          </section>
          <section className="rounded-card border border-line bg-surface p-5">
            <h3 className="font-semibold">How recommendations work</h3>
            <p className="mt-2 text-sm leading-6 text-muted">The demo first checks that both profiles’ age and gender preferences align. It then compares the profile details and optional questionnaire answers available on both sides.</p>
            <p className="mt-3 text-xs leading-5 text-muted">The weights are initial product hypotheses, not validated science. No sensitive traits are inferred.</p>
          </section>
          <section className="rounded-card border border-line bg-surface p-5">
            <h3 className="font-semibold">Saved profiles</h3>
            {saved.length ? <ul className="mt-3 space-y-3">{saved.map((candidate) => <li key={candidate.id} className="flex items-center justify-between gap-2 text-sm"><span>{candidate.displayName}, {candidate.age}</span><span className="text-xs text-muted">{candidate.city}</span></li>)}</ul> : <p className="mt-2 text-sm text-muted">Profiles you save will appear here.</p>}
          </section>
          <p className="flex items-start gap-2 text-xs leading-5 text-muted"><Check className="mt-0.5 size-4 shrink-0" aria-hidden />All actions are stored locally in this browser only. Nothing is sent to another person or account.</p>
        </aside>
      </div>
    </div>
  );
}
