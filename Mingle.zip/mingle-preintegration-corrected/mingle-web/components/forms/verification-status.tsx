"use client";

import { useActionState } from "react";
import { Button } from "@/components/ui/button";
import { Field } from "@/components/ui/field";
import { FormNotice } from "@/components/forms/form-notice";
import { resendVerificationAction } from "@/lib/auth/actions";
import { initialAuthFormState } from "@/lib/auth/form-state";

export function VerificationStatus({ email = "" }: { email?: string }) {
  const [state, action, pending] = useActionState(resendVerificationAction, initialAuthFormState);
  return (
    <div className="mt-8 flex flex-col gap-5">
      <FormNotice tone="info">Email confirmation is handled by Supabase. After confirmation, Mingle still requires a separate provider-backed age check and an enabled launch market before member access is granted.</FormNotice>
      {state.message ? <FormNotice tone="info">{state.message}</FormNotice> : null}
      {state.status === "error" ? <FormNotice tone="error">{state.fieldErrors?.email || state.message}</FormNotice> : null}
      <form action={action} className="flex flex-col gap-3">
        <h2 className="text-body font-semibold">Need another confirmation email?</h2>
        <Field label="Email" name="email" type="email" autoComplete="email" required defaultValue={email || state.email} error={state.fieldErrors?.email} />
        <Button type="submit" variant="secondary" className="self-start" loading={pending}>Resend verification email</Button>
      </form>
      <div className="border-t border-line pt-5">
        <p className="text-caption font-semibold text-foreground">Next step: age assurance</p>
        <p className="mt-1 text-caption text-muted">The age-assurance provider has not yet been selected or integrated. Access stays closed until a real provider returns a verified result.</p>
      </div>
    </div>
  );
}
