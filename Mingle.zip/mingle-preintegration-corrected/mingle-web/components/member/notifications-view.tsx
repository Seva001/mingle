"use client";

import { useMemo, useState } from "react";
import { Bell, Check, CheckCheck, Heart, MessageCircle, ShieldCheck, UserRound, type LucideIcon } from "lucide-react";
import { Avatar } from "@/components/ui/avatar";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";

type Category = "matches" | "messages" | "safety" | "account";
type Notice = { id: string; category: Category; title: string; body: string; time: string; read: boolean; person?: string };
const INITIAL_NOTICES: Notice[] = [
  { id: "n1", category: "matches", title: "A compatibility highlight", body: "Avery shares several interests in this fictional preview.", time: "Today · 10:42 AM", read: false, person: "Avery" },
  { id: "n2", category: "messages", title: "A new message preview", body: "Jordan's sample conversation has an unread message.", time: "Yesterday", read: false, person: "Jordan" },
  { id: "n3", category: "safety", title: "A safety reminder", body: "Keep personal information private while getting to know someone.", time: "2 days ago", read: true },
  { id: "n4", category: "account", title: "Profile checklist", body: "Review your interests and relationship preferences in your profile preview.", time: "3 days ago", read: true },
];
const FILTERS: { value: "all" | Category; label: string }[] = [
  { value: "all", label: "All" }, { value: "matches", label: "Matches" }, { value: "messages", label: "Messages" }, { value: "safety", label: "Safety" }, { value: "account", label: "Account" },
];
const ICONS: Record<Category, LucideIcon> = { matches: Heart, messages: MessageCircle, safety: ShieldCheck, account: UserRound };

export function NotificationsView() {
  const [items, setItems] = useState(INITIAL_NOTICES);
  const [filter, setFilter] = useState<(typeof FILTERS)[number]["value"]>("all");
  const unreadCount = items.filter((item) => !item.read).length;
  const visible = useMemo(() => items.filter((item) => filter === "all" || item.category === filter), [items, filter]);

  function markRead(id: string) { setItems((current) => current.map((item) => item.id === id ? { ...item, read: true } : item)); }
  function markAllRead() { setItems((current) => current.map((item) => ({ ...item, read: true }))); }

  return (
    <div className="space-y-5">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div><p className="text-sm text-muted">A single place for important activity.</p><p className="mt-1 text-xs text-muted">All entries below are fictional examples, not delivered notifications.</p></div>
        <Button variant="secondary" size="sm" onClick={markAllRead} disabled={unreadCount === 0}><CheckCheck className="size-4" aria-hidden />Mark all read</Button>
      </div>
      <div className="flex flex-wrap gap-2" aria-label="Notification categories">
        {FILTERS.map((item) => <button key={item.value} type="button" aria-pressed={filter === item.value} onClick={() => setFilter(item.value)} className={`rounded-full border px-3.5 py-2 text-xs font-semibold ${filter === item.value ? "border-foreground bg-foreground text-background" : "border-line bg-surface text-muted"}`}>{item.label}{item.value === "all" ? ` (${items.length})` : ""}</button>)}
      </div>
      <Card padded={false}>
        <div className="flex items-center justify-between border-b border-line px-5 py-4"><div className="flex items-center gap-2"><Bell className="size-4 text-muted" aria-hidden /><h2 className="text-sm font-semibold">Recent activity</h2></div><span className="text-xs text-muted">{unreadCount} unread</span></div>
        {visible.length ? <ul className="divide-y divide-line">{visible.map((item) => {
          const Icon = ICONS[item.category];
          return <li key={item.id} className={`flex gap-3 px-5 py-4 ${item.read ? "" : "bg-foreground/[0.025]"}`}>
            {item.person ? <Avatar name={item.person} size={42} highlighted={!item.read} /> : <span className="flex size-[42px] shrink-0 items-center justify-center rounded-full border border-line bg-background"><Icon className="size-4 text-muted" aria-hidden /></span>}
            <div className="min-w-0 flex-1"><div className="flex flex-wrap items-center gap-2"><p className="text-sm font-semibold">{item.title}</p>{!item.read ? <span className="size-2 rounded-full bg-brand" aria-label="Unread" /> : null}</div><p className="mt-1 text-sm leading-6 text-muted">{item.body}</p><p className="mt-2 text-[11px] text-muted">{item.time} · {item.category}</p></div>
            {!item.read ? <button type="button" onClick={() => markRead(item.id)} className="self-center rounded-full p-2 text-muted hover:bg-foreground/5" aria-label={`Mark ${item.title} as read`}><Check className="size-4" aria-hidden /></button> : <span className="self-center text-[10px] text-muted">Read</span>}
          </li>;
        })}</ul> : <div className="p-8 text-center"><Bell className="mx-auto size-6 text-muted" aria-hidden /><p className="mt-3 text-sm font-semibold">Nothing in this category</p><p className="mt-1 text-xs text-muted">Try another category to view the sample activity.</p></div>}
      </Card>
      <p role="note" className="text-xs leading-5 text-muted">Read states work in this page preview only and reset when the page is refreshed. Push, email and in-app delivery are not connected.</p>
    </div>
  );
}
