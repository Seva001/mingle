"use client";

import Link from "next/link";
import { useEffect, useMemo, useState } from "react";
import { Heart, MessageCircle, Users } from "lucide-react";
import { DISCOVERY_FIXTURES } from "@/lib/discovery/fixtures";
import { readDiscoveryActions, setDiscoveryAction, subscribeDiscoveryActions } from "@/lib/discovery/demo-store";
import type { DiscoveryActions } from "@/lib/discovery/types";
import { Card } from "@/components/ui/card";
import { Button, ButtonLink } from "@/components/ui/button";

export function ConnectionsView() {
  const [actions, setActions] = useState<DiscoveryActions>({});
  useEffect(() => {
    setActions(readDiscoveryActions());
    return subscribeDiscoveryActions(() => setActions(readDiscoveryActions()));
  }, []);

  const interests = useMemo(
    () => DISCOVERY_FIXTURES.filter((candidate) => actions[candidate.id] === "liked"),
    [actions],
  );
  const blocked = useMemo(
    () => DISCOVERY_FIXTURES.filter((candidate) => actions[candidate.id] === "blocked"),
    [actions],
  );

  return (
    <div className="space-y-6">
      <Card>
        <div className="flex items-start gap-4">
          <div className="rounded-full border border-line p-3"><Users className="size-5" aria-hidden /></div>
          <div>
            <h2 className="text-title font-semibold">Your connections</h2>
            <p className="mt-1 text-sm leading-6 text-muted">Confirmed mutual connections will appear here when matching and account services are operational.</p>
          </div>
        </div>
        <p className="mt-5 rounded-control border border-line p-4 text-sm text-muted" role="status">No real connections are available in this frontend preview. An interest from a demo profile is not a match and does not notify another person.</p>
      </Card>

      <section aria-labelledby="interest-signals-title" className="space-y-4">
        <div>
          <h2 id="interest-signals-title" className="text-title font-semibold">Your interest signals</h2>
          <p className="mt-1 text-caption text-muted">Local preview actions only. These are synthetic profiles, not real members.</p>
        </div>
        {interests.length ? (
          <ul className="grid gap-3 sm:grid-cols-2">
            {interests.map((candidate) => (
              <li key={candidate.id}>
                <Card>
                  <div className="flex items-center gap-3">
                    <div aria-hidden className="flex size-11 shrink-0 items-center justify-center rounded-full border border-line bg-surface-raised font-semibold">{candidate.displayName.slice(0, 1)}</div>
                    <div className="min-w-0 flex-1">
                      <p className="font-semibold">{candidate.displayName}, {candidate.age}</p>
                      <p className="text-caption text-muted">{candidate.city}, {candidate.country} · Synthetic demo</p>
                    </div>
                    <Heart className="size-4 shrink-0" aria-hidden />
                  </div>
                </Card>
              </li>
            ))}
          </ul>
        ) : (
          <Card>
            <p className="text-sm text-muted">You have not marked any demo profiles as interested yet.</p>
            <ButtonLink href="/discover" variant="secondary" className="mt-4">Explore discovery</ButtonLink>
          </Card>
        )}
      </section>

      {blocked.length ? (
        <section aria-labelledby="blocked-demo-title" className="space-y-3">
          <div><h2 id="blocked-demo-title" className="text-title font-semibold">Blocked demo profiles</h2><p className="mt-1 text-caption text-muted">These controls affect synthetic profiles in this browser only.</p></div>
          <ul className="space-y-2">
            {blocked.map((candidate) => (
              <li key={candidate.id}><Card><div className="flex items-center justify-between gap-3"><span className="text-sm font-semibold">{candidate.displayName} · Synthetic demo</span><Button size="sm" variant="secondary" onClick={() => setDiscoveryAction(candidate.id, null)}>Unblock</Button></div></Card></li>
            ))}
          </ul>
        </section>
      ) : null}

      <Card>
        <div className="flex items-start gap-3">
          <MessageCircle className="mt-1 size-5 shrink-0" aria-hidden />
          <div>
            <h2 className="font-semibold">Messaging is not connected</h2>
            <p className="mt-1 text-sm leading-6 text-muted">A real conversation can only begin after a server-confirmed mutual connection. No chat can be started from this preview.</p>
            <Link href="/chats" className="mt-3 inline-block text-caption font-semibold underline">View chats</Link>
          </div>
        </div>
      </Card>
    </div>
  );
}
