"use client";

import { useMemo, useState, type FormEvent } from "react";
import { ArrowLeft, Check, CheckCheck, ChevronRight, MessageCircle, MoreHorizontal, Search, Send, ShieldCheck } from "lucide-react";
import { DISCOVERY_FIXTURES } from "@/lib/discovery/fixtures";
import { Avatar } from "@/components/ui/avatar";
import { Button } from "@/components/ui/button";


type DemoMessage = { id: string; body: string; from: "you" | "them"; time: string; read?: boolean };
type DemoConversation = {
  id: string;
  profileId: string;
  preview: string;
  time: string;
  unread: number;
  messages: DemoMessage[];
};

// Fictional conversations are used only to demonstrate the chat layout and interactions.
const INITIAL_CONVERSATIONS: DemoConversation[] = [
  { id: "chat-avery", profileId: "fixture-01", preview: "That sounds like a great weekend plan.", time: "10:42 AM", unread: 2, messages: [
    { id: "a1", body: "Hey! I noticed we both enjoy discovering new places.", from: "them", time: "10:35 AM" },
    { id: "a2", body: "I am always looking for a new coffee spot. Any favourites?", from: "you", time: "10:38 AM", read: true },
    { id: "a3", body: "That sounds like a great weekend plan.", from: "them", time: "10:42 AM" },
  ] },
  { id: "chat-jordan", profileId: "fixture-02", preview: "I have been trying a new recipe lately.", time: "Yesterday", unread: 0, messages: [
    { id: "j1", body: "What is your go-to comfort meal?", from: "you", time: "Yesterday", read: true },
    { id: "j2", body: "I have been trying a new recipe lately.", from: "them", time: "Yesterday" },
  ] },
  { id: "chat-morgan", profileId: "fixture-03", preview: "A good bookshop and coffee is hard to beat.", time: "Tue", unread: 0, messages: [
    { id: "m1", body: "A good bookshop and coffee is hard to beat.", from: "them", time: "Tue" },
  ] },
];

export function ChatsView() {
  const [conversations, setConversations] = useState(INITIAL_CONVERSATIONS);
  const [activeId, setActiveId] = useState<string | null>(null);
  const [query, setQuery] = useState("");
  const [view, setView] = useState<"all" | "unread">("all");
  const [draft, setDraft] = useState("");
  const [notice, setNotice] = useState("");

  const visible = useMemo(() => conversations.filter((conversation) => {
    const person = DISCOVERY_FIXTURES.find((candidate) => candidate.id === conversation.profileId);
    const matchesQuery = !query.trim() || `${person?.displayName ?? ""} ${conversation.preview}`.toLowerCase().includes(query.trim().toLowerCase());
    return matchesQuery && (view === "all" || conversation.unread > 0);
  }), [conversations, query, view]);
  const active = conversations.find((conversation) => conversation.id === activeId) ?? null;
  const activeProfile = active ? DISCOVERY_FIXTURES.find((candidate) => candidate.id === active.profileId) : null;

  function openConversation(id: string) {
    setActiveId(id);
    setConversations((current) => current.map((conversation) => conversation.id === id ? { ...conversation, unread: 0 } : conversation));
    setNotice("Opened a fictional conversation preview. No real member has been contacted.");
  }

  function sendMessage(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    const body = draft.trim();
    if (!body || !activeId) return;
    const now = new Date();
    const time = now.toLocaleTimeString([], { hour: "numeric", minute: "2-digit" });
    setConversations((current) => current.map((conversation) => conversation.id === activeId ? {
      ...conversation,
      preview: body,
      time: "Now",
      messages: [...conversation.messages, { id: `local-${Date.now()}`, body, from: "you", time, read: false }],
    } : conversation));
    setDraft("");
    setNotice("Message added to this temporary preview only. It was not sent or stored.");
  }

  return (
    <div className="space-y-3">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div>
          <p className="text-xs font-bold uppercase tracking-[0.16em] text-brand">Your conversations</p>
          <p className="mt-1 text-sm text-muted">A familiar match-first inbox, demonstrated with fictional profiles.</p>
        </div>
        <span className="rounded-full border border-line px-3 py-1.5 text-xs text-muted">Preview only</span>
      </div>

      <div className="grid min-h-[34rem] grid-cols-1 overflow-hidden rounded-card border border-line bg-surface shadow-card md:grid-cols-[18rem_minmax(0,1fr)]">
        <div className="border-b border-line p-4 md:col-span-2">
          <div className="mb-3 flex items-center justify-between gap-3"><div><h2 className="text-sm font-semibold">Match previews</h2><p className="text-[11px] text-muted">Fictional profiles to preview the familiar matches strip.</p></div><span className="text-[10px] text-muted">Demo only</span></div>
          <div className="flex gap-4 overflow-x-auto pb-1 scrollbar-none">{conversations.map((conversation) => { const person = DISCOVERY_FIXTURES.find((candidate) => candidate.id === conversation.profileId); if (!person) return null; return <button key={conversation.id} type="button" onClick={() => openConversation(conversation.id)} className="flex w-16 shrink-0 flex-col items-center gap-1.5 text-center"><Avatar name={person.displayName} size={52} highlighted={conversation.unread > 0} /><span className="w-full truncate text-[11px] font-medium">{person.displayName}</span></button>; })}</div>
        </div>
        <section className={`${activeId ? "hidden md:flex" : "flex"} min-h-[34rem] flex-col border-line md:border-r`} aria-label="Conversation list">
          <div className="border-b border-line p-4">
            <div className="relative">
              <Search className="pointer-events-none absolute left-3 top-1/2 size-4 -translate-y-1/2 text-muted" aria-hidden />
              <input aria-label="Search conversations" value={query} onChange={(event) => setQuery(event.target.value)} placeholder="Search messages" className="h-11 w-full rounded-control border border-line bg-background pl-9 pr-3 text-sm text-foreground placeholder:text-muted" />
            </div>
            <div className="mt-3 flex gap-2" aria-label="Conversation filter">
              <button type="button" aria-pressed={view === "all"} onClick={() => setView("all")} className={`rounded-full border px-3 py-1.5 text-xs font-semibold ${view === "all" ? "border-foreground bg-foreground text-background" : "border-line text-muted"}`}>All</button>
              <button type="button" aria-pressed={view === "unread"} onClick={() => setView("unread")} className={`rounded-full border px-3 py-1.5 text-xs font-semibold ${view === "unread" ? "border-foreground bg-foreground text-background" : "border-line text-muted"}`}>Unread</button>
            </div>
          </div>
          <div className="flex-1">
            {visible.length ? <ul className="divide-y divide-line">
              {visible.map((conversation) => {
                const person = DISCOVERY_FIXTURES.find((candidate) => candidate.id === conversation.profileId);
                if (!person) return null;
                return <li key={conversation.id}>
                  <button type="button" onClick={() => openConversation(conversation.id)} aria-current={activeId === conversation.id ? "true" : undefined} className={`flex w-full items-center gap-3 p-4 text-left transition-colors hover:bg-foreground/5 ${activeId === conversation.id ? "bg-foreground/5" : ""}`}>
                    <Avatar name={person.displayName} size={48} highlighted={conversation.unread > 0} />
                    <span className="min-w-0 flex-1">
                      <span className="flex items-center justify-between gap-2"><span className="truncate text-sm font-semibold">{person.displayName}</span><span className="shrink-0 text-[11px] text-muted">{conversation.time}</span></span>
                      <span className="mt-1 block truncate text-xs text-muted">{conversation.preview}</span>
                      <span className="mt-1 block text-[10px] text-muted">Synthetic demo profile</span>
                    </span>
                    {conversation.unread > 0 ? <span aria-label={`${conversation.unread} unread messages`} className="flex size-5 shrink-0 items-center justify-center rounded-full bg-brand text-[10px] font-bold text-on-brand">{conversation.unread}</span> : <ChevronRight className="size-4 shrink-0 text-muted" aria-hidden />}
                  </button>
                </li>;
              })}
            </ul> : <div className="p-6 text-center"><MessageCircle className="mx-auto size-6 text-muted" aria-hidden /><p className="mt-3 text-sm font-semibold">No conversations found</p><p className="mt-1 text-xs text-muted">Try another search or switch to All.</p></div>}
          </div>
          <p className="border-t border-line px-4 py-3 text-[11px] leading-5 text-muted">Fictional preview conversations only. Real messaging requires a confirmed mutual connection and secure delivery.</p>
        </section>

        <section className={`${activeId ? "flex" : "hidden md:flex"} min-h-[34rem] min-w-0 flex-col`} aria-label="Conversation detail">
          {active && activeProfile ? <>
            <header className="flex items-center gap-3 border-b border-line px-4 py-3">
              <button type="button" onClick={() => setActiveId(null)} className="rounded-full p-2 text-muted hover:bg-foreground/5 md:hidden" aria-label="Back to conversations"><ArrowLeft className="size-5" aria-hidden /></button>
              <Avatar name={activeProfile.displayName} size={42} />
              <div className="min-w-0 flex-1">
                <p className="truncate text-sm font-semibold">{activeProfile.displayName}, {activeProfile.age}</p>
                <p className="text-xs text-muted">{activeProfile.city} · Synthetic demo</p>
              </div>
              <span className="rounded-full border border-line px-2.5 py-1 text-[10px] text-muted">Preview</span>
              <button type="button" className="rounded-full p-2 text-muted hover:bg-foreground/5" aria-label="More conversation information" onClick={() => setNotice("Conversation options are unavailable in this frontend preview.")}><MoreHorizontal className="size-5" aria-hidden /></button>
            </header>
            <div className="flex items-center justify-center gap-2 border-b border-line px-4 py-2 text-[11px] text-muted"><ShieldCheck className="size-3.5" aria-hidden /> Be respectful. Never share passwords or sensitive documents.</div>
            <div className="flex-1 space-y-3 overflow-y-auto p-4" role="log" aria-live="polite" aria-relevant="additions text" aria-label="Messages">
              <div className="py-3 text-center"><span className="rounded-full border border-line px-3 py-1 text-[10px] text-muted">This is a fictional chat preview</span></div>
              {active.messages.map((message) => <div key={message.id} className={`flex ${message.from === "you" ? "justify-end" : "justify-start"}`}>
                <div className={`max-w-[82%] rounded-2xl px-4 py-2.5 ${message.from === "you" ? "rounded-br-md bg-brand text-on-brand" : "rounded-bl-md bg-foreground/5 text-foreground"}`}>
                  <p className="whitespace-pre-wrap break-words text-sm leading-6">{message.body}</p>
                  <p className={`mt-1 flex items-center justify-end gap-1 text-[10px] ${message.from === "you" ? "text-on-brand/75" : "text-muted"}`}>{message.time}{message.from === "you" ? (message.read ? <CheckCheck className="size-3" aria-label="Read in preview" /> : <Check className="size-3" aria-label="Added locally" />) : null}</p>
                </div>
              </div>)}
            </div>
            <form onSubmit={sendMessage} className="border-t border-line p-3">
              <label htmlFor="message-draft" className="sr-only">Write a message</label>
              <div className="flex items-end gap-2">
                <textarea id="message-draft" rows={1} maxLength={1000} value={draft} onChange={(event) => setDraft(event.target.value)} placeholder="Write a message…" className="max-h-28 min-h-11 flex-1 resize-y rounded-control border border-line bg-background px-4 py-3 text-sm text-foreground placeholder:text-muted" />
                <Button type="submit" size="md" disabled={!draft.trim()} aria-label="Add message to preview"><Send className="size-4" aria-hidden /><span className="hidden sm:inline">Send</span></Button>
              </div>
              <p className="mt-2 text-[10px] text-muted">Your message stays in temporary page state and disappears when you leave or refresh.</p>
            </form>
          </> : <div className="flex flex-1 flex-col items-center justify-center px-6 py-12 text-center">
            <div className="flex size-16 items-center justify-center rounded-full border border-line"><MessageCircle className="size-7 text-muted" aria-hidden /></div>
            <h2 className="mt-4 font-display text-xl font-semibold">Your messages, in one place.</h2>
            <p className="mt-2 max-w-sm text-sm leading-6 text-muted">Choose a conversation to open the chat. Real conversations will become available after secure matching and messaging services are connected.</p>
            <p role="status" className="mt-4 text-xs text-muted">Select a fictional conversation to explore the interface.</p>
          </div>}
        </section>
      </div>
      {notice ? <p role="status" className="text-xs leading-5 text-muted">{notice}</p> : null}
    </div>
  );
}
