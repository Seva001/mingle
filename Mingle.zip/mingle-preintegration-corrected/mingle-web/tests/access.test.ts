import { describe, expect, it } from "vitest";
import { decideMemberAccess, type AccessSubject } from "@/lib/auth/access";

const good: AccessSubject = { emailVerified: true, status: "active", ageAssurance: "passed" };
const deny = (s: AccessSubject | null) => decideMemberAccess(s);

describe("decideMemberAccess is fail-closed (brief §7, §15)", () => {
  it("allows only a verified, active, age-assured account", () => {
    expect(deny(good)).toEqual({ allowed: true });
  });
  it("sends signed-out visitors to sign in", () => {
    expect(deny(null)).toEqual({ allowed: false, reason: "signed_out", destination: "/sign-in" });
  });
  it("requires a verified email first", () => {
    expect(deny({ ...good, emailVerified: false })).toMatchObject({
      allowed: false,
      reason: "email_unverified",
      destination: "/verify",
    });
  });
  it.each(["not_started", "pending", "error"] as const)(
    "never admits age assurance = %s",
    (ageAssurance) => {
      expect(deny({ ...good, ageAssurance })).toMatchObject({
        allowed: false,
        reason: "age_assurance_required",
      });
    },
  );
  it("refuses a failed age check", () => {
    expect(deny({ ...good, ageAssurance: "failed" })).toMatchObject({
      allowed: false,
      reason: "age_assurance_failed",
    });
  });
  it.each(["blocked_underage", "suspended", "deleted", "pending"] as const)(
    "refuses status = %s",
    (status) => {
      expect(deny({ ...good, status })).toMatchObject({ allowed: false });
    },
  );
  it("routes a confirmed but market-pending account to eligibility", () => {
    expect(deny({ ...good, status: "pending" })).toEqual({
      allowed: false,
      reason: "eligibility_pending",
      destination: "/eligibility",
    });
  });
  it("a declared date of birth alone can never grant access", () => {
    expect(
      deny({ emailVerified: true, status: "pending", ageAssurance: "not_started" }),
    ).toMatchObject({ allowed: false });
  });
});
